trajectories
============

[![Build Status](https://travis-ci.org/edzer/trajectories.png?branch=master)](https://travis-ci.org/edzer/trajectories) [![CRAN](http://www.r-pkg.org/badges/version/trajectories)](http://cran.rstudio.com/package=trajectories) [![Downloads](http://cranlogs.r-pkg.org/badges/trajectories?color=brightgreen)](http://www.r-pkg.org/pkg/trajectories)

R package for handling and analyzing trajectories
